import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-slytherin',
  templateUrl: './slytherin.component.html',
  styleUrls: ['./slytherin.component.css']
})
export class SlytherinComponent implements OnInit {
  slytherin;

  constructor(private apiService: ApiService) { }
  ngOnInit() {

    this.apiService.getHouseSlytherin()
      .subscribe(
        (data) => {
          this.slytherin = data
        }
      );
  }
}
