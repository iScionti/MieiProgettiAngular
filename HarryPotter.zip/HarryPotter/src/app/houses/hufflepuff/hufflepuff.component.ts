import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-hufflepuff',
  templateUrl: './hufflepuff.component.html',
  styleUrls: ['./hufflepuff.component.css']
})
export class HufflepuffComponent implements OnInit {
  hufflepuff;

  constructor(private apiService: ApiService) { }
  ngOnInit() {
    this.apiService.getHouseHufflepuff()
      .subscribe(
        (data) => {
          this.hufflepuff = data
        }
      );
  }
}
