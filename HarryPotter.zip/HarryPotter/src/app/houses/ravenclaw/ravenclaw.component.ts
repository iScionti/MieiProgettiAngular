import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-ravenclaw',
  templateUrl: './ravenclaw.component.html',
  styleUrls: ['./ravenclaw.component.css']
})
export class RavenclawComponent implements OnInit {
ravenclaw;
  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getHouseRavenclaw().subscribe((data)=>
    {
      this.ravenclaw = data
    }
    );
  }
}
