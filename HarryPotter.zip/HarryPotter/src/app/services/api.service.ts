import { Injectable } from '@angular/core';
import {catchError } from 'rxjs/operators'; //rxjs è una libreria che consente l'utilizzo di un observable il quale viene utilizzato per le operazioni asincrone
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ApiService {

  private baseUrl:String = 'http://hp-api.herokuapp.com/api'; //la base url dell'api su cui andremo ad operare

  private httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*', //chi effettua la chiamata
      'Access-Control-Allow-Methods':'GET, POST, DELETE, PUT', //metodi http accettati
      'Content-Type':'application/json' //tipo di contenuto
    }) //gestione dell'http.
  };

  constructor(private _http: HttpClient) { }

  public getCharacters() {
   return this._http.get(this.baseUrl+'/characters', this.httpOptions).pipe(catchError(this.errorHandler<any>('getCharacters')));
  
  }

  public getStaff() {
   return this._http.get(this.baseUrl+'/characters/staff', this.httpOptions).pipe(catchError(this.errorHandler<any>('getStaff')));
  
  }

  public getStudent() {
   return this._http.get(this.baseUrl+'/characters/students', this.httpOptions).pipe(catchError(this.errorHandler<any>('getStudent')));
  
  }

  public getHouse() {
   return this._http.get(this.baseUrl+'/characters/house/gryffindor', this.httpOptions).pipe(catchError(this.errorHandler<any>('getHouse')));
  }
  public getHouseGryffindor() {
    return this._http.get(this.baseUrl+'/characters/house/gryffindor', this.httpOptions).pipe(catchError(this.errorHandler<any>('getHouseGryffindor')));
   }
   public getHouseSlytherin() {
    return this._http.get(this.baseUrl+'/characters/house/slytherin', this.httpOptions).pipe(catchError(this.errorHandler<any>('getHouseSlytherin')));
   }
   public getHouseHufflepuff() {
    return this._http.get(this.baseUrl+'/characters/house/hufflepuff', this.httpOptions).pipe(catchError(this.errorHandler<any>('getHouseHufflepuff')));
   }
   public getHouseRavenclaw() {
    return this._http.get(this.baseUrl+'/characters/house/ravenclaw', this.httpOptions).pipe(catchError(this.errorHandler<any>('getHouseRavenclaw')));
   }

   private errorHandler<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); 
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
