import { Component } from '@angular/core';
import { QUOTES } from '../app/models/database';
import { Quotation } from './models/quotation';

//logica di bussiness del progetto

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title:String;
  
  showForm = false;   // campo per la visualizzazione del form
  quotes: Quotation[] = QUOTES;   //nuovo campo per la riproduzione dell'elenco delle citazioni
  quotation: Quotation = {
    author: '',
    sentence: '',
    votes: 0
  };  // campo per magazzinare dati inseriti nel progetto

  onSwitchForm(): void {
    this.showForm = !this.showForm;
  }

  addQuotation() {
    this.quotes.unshift(this.quotation);  //aggiungo una citazione
    this.quotation = {
      author: '',
      sentence: '',
      votes: 0
    };   // campo di citazione nuovo
  }

  addVote(quotation: Quotation, value: number) {
    quotation.votes += value; 
  }

  bestQuotes() {
    return this.quotes.filter(q => q.votes > 0); //filtro per cercare le migliori quotazioni
  }

  worstQuotes() {
    return this.quotes.filter(q => q.votes < 0); //filtro per cercare le peggiorni quotazioni
  }
}