//mi creo una interfaccia "quotation" per stabilire una regola di base all'interno del mio model

export interface Quotation {
    author: string;
    sentence: string;
    votes: number;
}