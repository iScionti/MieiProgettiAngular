import { Quotation } from './quotation';

//esempio di database noquery (quindi un dbms normale)

export const QUOTES: Quotation[] = [
  {
    author: 'Franco Battiato',
    sentence: 'Non voglio sentirmi intelligente guardando dei cretini, voglio sentirmi cretino guardando personeintelligenti.',
    votes: 3,
  },
  {
    author: 'Giacomo Leopardi',
    sentence: 'Gli uomini sarebbero felici se non avessero cercato e non cercassero di esserlo.',
    votes: -2,
  },
  {
    author: 'Niccolò Ammaniti',
    sentence: 'La vita è più forte di tutto. La vita non ci appartiene, ci attraversa.',
    votes: 1,
  },
  {
    author: 'Oscar Wilde',
    sentence: ' Sii te stesso, tutto il resto è già stato preso. (Be yourself; everyone else is already taken).',
    votes: 3,
  },
  {
    author: 'Albert Einstein',
    sentence: 'Due cose sono infinite: l’universo e la stupidità umana, ma riguardo l’universo ho ancora dei dubbi. (Two things are infinite: the universe and human stupidity; and I’m not sure about the universe)',
    votes: -8,
  },
  {
    author: 'Italo Svevo',
    sentence: 'Si piange quando si grida all’ingiustizia.',
    votes: 0,
  },
];